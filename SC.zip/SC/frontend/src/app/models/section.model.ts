export class SECTION {
    id?: any;
    section?:String;
    standard?:String;
    classteacherid?:String;
  }

