export class Mes {
    name?: string;
    email?: string;
    designation?: string;
    phoneNumber?: number;
  }
  