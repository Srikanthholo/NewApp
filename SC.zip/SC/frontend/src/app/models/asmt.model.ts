export class ASMT {
    id?: any;
    title?: String;
    description?: String;
    studentid?: String;
    customerid?: String;
    attachedurl?:String;
    published?: Boolean;
    createdAt?: string;
    
  }