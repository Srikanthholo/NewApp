import { Component, OnInit } from '@angular/core';
import { StudentService } from '../_services/student.service';
import { TokenStorageService } from '../_services/token-storage.service';

@Component({
  selector: 'app-boardinstitute',
  templateUrl: './boardinstitute.component.html',
  styleUrls: ['./boardinstitute.component.css']
})
export class BoardinstituteComponent implements OnInit {
  currentUser: any;
  currentuserid: any;
  code: any;
  studentData: any;
 

  constructor(private tokenStorage: TokenStorageService,
    private studnetservice : StudentService,
    ) { }

  ngOnInit(): void {

     
    this.currentUser = this.tokenStorage.getUser();
    this.currentuserid  =this.currentUser.id;

    this.getmydetails(this.currentUser.id);

  }


    getmydetails(id: string): void {
 
    this.studnetservice.get(id)
      .subscribe({
        next: (data) => {
          this.currentUser = data;
          
          this.code = this.currentUser.code;
          this.retrieveStudents(this.code)

        },
        error: (e) => console.error(e)
      });
  }


  
  retrieveStudents(code :any){

    this.studnetservice.findBycode(code)
    .subscribe({
      next: (data) => {
         this.studentData = data;
 
  
      },
      error: (e) => console.error(e)
    });

  }




}
