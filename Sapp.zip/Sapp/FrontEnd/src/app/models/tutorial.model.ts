export class Tutorial {
    id?: any;
    title?: string;
    description?: string;
    studentid?: string;
    customerid?: string;
    published?: boolean;
    createdAt?: string;
    
  }