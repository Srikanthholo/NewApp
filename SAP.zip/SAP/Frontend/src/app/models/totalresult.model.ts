 
export class TRESULTS {
    id?: any;
    studentid?:String;
    photourl?:String;
    studentname?:String;
    exam?:String;
     s1?:Number;
     s2?:Number;
     s3?:Number;
     s4?:Number;
     s5?:Number;
     s6?:Number;
    section?:String;
    totalmarks?:String;
    rank?:Number;
    totalattended?:String;

  
  }

 