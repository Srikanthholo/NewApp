import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Invoice } from 'src/app/models/accounts.model';
import { AccountService } from 'src/app/_services/account.service';
import { AuthService } from 'src/app/_services/auth.service';
import { FileUploadService } from 'src/app/_services/fileUploadService';
import { PaymentService } from 'src/app/_services/pay.service';
import { StudentService } from 'src/app/_services/student.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';

@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.css']
})
export class FeesComponent implements OnInit {


  invocies?: Invoice[];
  currentInvoice: Invoice = {};

  searchterm = "";
  page: number = 1;
  count: number = 0;  
  tableSize: number= 50;
  tableSizes: any = [10, 15, 20, 50, 100];
  currentUser: any;
  totalRecords: any;
  currentTutorial:any;
  paymentHandler: any = null;

  currentdata: Invoice = {
  
  };



  constructor(
 
    private studentservice:StudentService, 
    private authService: AuthService, 
    private uploadService: FileUploadService,
    private tokenStorage: TokenStorageService, 
    private  accountService: AccountService,
    private paymentService :PaymentService,
    public router: Router
  ) { }

  ngOnInit(): void {

    this.currentUser = this.tokenStorage.getUser();
 
    this.getmyinvoices(this.currentUser.id);
  
 
  }


  getmyinvoices(studentid :any)
    {

      debugger
    
      this.accountService.findByStudentid(studentid)
      .subscribe({
        next: (data) => {
          this.invocies = data;
          this.totalRecords=this.invocies.length;
          console.log(data);
          this.currentTutorial =this.invocies[this.totalRecords-1];
          
        },
        error: (e) => console.error(e)
      });

    }


    getcurrentinvoice(invoiceid :any)
    {

      
    
      this.accountService.get(invoiceid)
      .subscribe({
        next: (data) => {
           
          this.currentdata =  data;
          
        },
        error: (e) => console.error(e)
      });

    }



  onTableDataChange( event: any){
     
    this.page = event;
    this.getmyinvoices(this.currentUser._id);
  }
  onTableSizeChange( event: any){
    this.tableSize= event.target.value;
    this.page = 1;
    this.getmyinvoices(this.currentUser._id);
  }
      
      
  reloadPage(): void {
    window.location.reload();
  }



  Payinvocie(): void {
     
    const data = {
      
      customerid: this.currentUser.id,
      section: this.currentUser.section,
      feeformat : this.currentInvoice.feeformat,
      amount : this.currentInvoice.total
    };

    this.paymentService.create(data)
      .subscribe({
        next: (res) => {
          console.log(res);
          
        },
        error: (e) => console.error(e)
      });

    
     this.reloadPage();
       
     
  }

  

  makePayment(amount: any, feeformat:any) {

    this.invokeStripe();

    const paymentHandler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_51LYOsRSDQaUfYA3CALTWIZHakGxoGSh0g5qCCU725cSCilkbmvfMZI4FcxHGCMdQ8B6iHoTPSlLFWM6ZcyqosMKU00n4ws2w9h',
      locale: 'auto',
      token: function (stripeToken: any) {
        console.log(stripeToken);  
        alert('Stripe token generated!');
      },
    });




    paymentHandler.open({
      name: "XRGURU",
      description: feeformat,
      amount: amount * 100,
      email: this.currentUser.email
    });
     
    
  }
  invokeStripe() {
    if (!window.document.getElementById('stripe-script')) {
      const script = window.document.createElement('script');
      script.id = 'stripe-script';
      script.type = 'text/javascript';
      script.src = 'https://checkout.stripe.com/checkout.js';
      script.onload = () => {
        this.paymentHandler = (<any>window).StripeCheckout.configure({
          key: 'pk_test_51LYOsRSDQaUfYA3CALTWIZHakGxoGSh0g5qCCU725cSCilkbmvfMZI4FcxHGCMdQ8B6iHoTPSlLFWM6ZcyqosMKU00n4ws2w9h',
          locale: 'auto',
          token: function (stripeToken: any) {
            console.log(stripeToken);
            alert('Payment has been successfull!');
          },
        });
      };
      window.document.body.appendChild(script);
    }
  }





}
