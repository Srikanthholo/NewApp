

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TRESULTS } from '../models/totalresult.model';
 

const baseUrl = 'http://localhost:8080/api/totalresults';
 
@Injectable({
  providedIn: 'root'
})
export class TresultService {

 
  constructor(private http: HttpClient) { }

  getAll(): Observable<TRESULTS[]> {
    return this.http.get<TRESULTS[]>(baseUrl);
  } 

  get(id: any): Observable<TRESULTS> {
    return this.http.get<TRESULTS>(`${baseUrl}/${id}`);
  }

 
  create(data: any): Observable<any> {

    console.log(data);
 
    return this.http.post(baseUrl, data);
  }

  update(id: any, data: any): Observable<any> {
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  delete(id: any): Observable<any> {
    return this.http.delete(`${baseUrl}/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(baseUrl);
  }

  findByTitle(title: any): Observable<TRESULTS[]> {
    return this.http.get<TRESULTS[]>(`${baseUrl}?title=${title}`);
  }

  findByCustmerid(customerid: any): Observable<TRESULTS[]> {
  
 
    return this.http.get<TRESULTS[]>(`${baseUrl}?customerid=${customerid}`);
     
  }

  findByclass(section: any): Observable<TRESULTS[]> {
    return this.http.get<TRESULTS[]>(`${baseUrl}?section=${section}`);
  }

 

  findByStudentid(eid: any, sid:any): Observable<TRESULTS> {
    return this.http.get<TRESULTS>(`${baseUrl}/sm/?studentid=${sid}&examid=${eid}`);
  }


  findByexam(examid: any): Observable<TRESULTS[]> {
    return this.http.get<TRESULTS[]>(`${baseUrl}?examid=${examid}`);
  }

   
}


