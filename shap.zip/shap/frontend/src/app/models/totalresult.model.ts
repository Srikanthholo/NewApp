 
export class TRESULTS {
    id?: any;
    exam?:String;
    studentid?:String;
    studentname?:String;
    section?:String;
    standard?:String;
    totalmarks?:String;
    marksobtained?:String;
    attachmenturl?:String;
    totalattended?:String;
    rank?:String;
    ispassed?:String;
    is_attended?:String;
  
  }

 