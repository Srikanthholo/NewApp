export class Invoice {
    id?: any;
    name?:String;
    studentid?:String;
    admissionno?:String;
    standard?:String;
    feeformat?:String;
    lastdate?:String;
    tutionfee?:String;
    transportfee?:String;
    termfee?:String;
    total?:String;
    ispaid?: Boolean;
  


  }