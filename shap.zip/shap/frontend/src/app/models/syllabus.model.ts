export class SYLLABUS {
    id?: any;
    subject?: string;
    description?: string;
    standard?: string;
    section?: string;
    chapterno?: string;
    chaptertitle?: string;
    attachmenturl?: string;
    videourl?: string;
    filetype?: string;
 
  }