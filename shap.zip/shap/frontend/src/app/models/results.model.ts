export class RESULTS {
    id?: any;
    examid?:String;
    studentid?:String;
    studentname?:String;
    totalmarks?:String;
    marksobtained?:String;
    attachmenturl?:String;
    is_attended?: Boolean;
    ispassed?: Boolean;
    totalattended?:String;
    rank?:String;
 


  }

