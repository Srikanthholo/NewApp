export class SUBJECT {
    id?: any;
    subject?:String;
    hodid?:String;
  }

