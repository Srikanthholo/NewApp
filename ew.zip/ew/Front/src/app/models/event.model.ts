export class EVENT {
    id?: any;
    title?: string;
    description?: string;
    date?: string;
    section?: string;
    studentid?: any;
    customerid?: string;
    published?: boolean;
    createdAt?: string;
    
  }