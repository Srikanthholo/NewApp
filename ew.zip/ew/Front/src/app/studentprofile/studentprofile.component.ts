import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from '../_services/student.service';

@Component({
  selector: 'app-studentprofile',
  templateUrl: './studentprofile.component.html',
  styleUrls: ['./studentprofile.component.css']
})
export class StudentprofileComponent implements OnInit {
  id!:any;
  profileData!: any;
  constructor( private route: ActivatedRoute, private studentservice: StudentService ,  ) { }

  ngOnInit(): void {
 
    console.log(this.route.snapshot.params['id']);
    this.id = this.route.snapshot.params['id'];
    
    this.getstudent(this.id );

 
  }
 
   

    getstudent(id:any){

      this.studentservice.get(id)
      .subscribe({
        next: (data) => {
    
          this.profileData = data;
          
          
          console.log(this.profileData);
        },
        error: (e) => console.error(e)
      });

      

 
  }
}