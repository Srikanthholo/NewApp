export class FILEBOX {
    id?: any;
    name?: String;
    size?: String;
    userid?: String;
    parent_id?: String;
    fileurl?: String;
    foldername?: String;
    filetype?: String;
    is_folder?: Boolean;


    
  }