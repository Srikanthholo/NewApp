export class EXAMS {
    id?: any;
    title?:String;
    date?:String;
    subject?:String;
    syllabus?:String;
    customerid?: String;
    section?: String;
    published?: Boolean;
    resultset?: Boolean;

  }