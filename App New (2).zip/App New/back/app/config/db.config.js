module.exports = {
  url: "mongodb+srv://sri2627:Jhp$2627@cluster0.fatnc.mongodb.net/students"
};
