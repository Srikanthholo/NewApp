import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/shared/api.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  public id! : any;
  profileData!: any;
  constructor( private route: ActivatedRoute, private apiservice: ApiService ,  ) { }

  ngOnInit(): void {

    console.log(this.route.snapshot.params['id']);
    this.getstudent();
    console.log(this.profileData);
 
  }

  getstudent(){

    console.log(this.route.snapshot.params['id'] + "method");

     this.apiservice.findprofile(this.route.snapshot.params['id']).subscribe(res=>{
      this.profileData = res;
      console.log(this.profileData.name);
    })
    }

 
  }
 