import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { AuthService } from '../../shared/services/auth.service';

import { StudentComponent } from '../student/student.component';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})

export class DashboardComponent implements OnInit {

  studentData!: any;
  searchterm!: any;
  page: number = 1;
  count: number = 0;
  tableSize: number= 10;
  tableSizes: any =[10, 15, 20, 50, 100]

  constructor(public authService: AuthService,  public  api: ApiService ) {}

  ngOnInit(): void {
   
   
   
   
   
   
   
    this.getAllStudents()


  }

  getAllStudents(){
    this.api.getStudents().subscribe(res=>{
    this.studentData = res;
    console.log(res)
    })
    }
}
