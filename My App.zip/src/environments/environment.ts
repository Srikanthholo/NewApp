// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
 apiKey: "AIzaSyAYpG4_41-LjwgXmjOq3ESAwmUJEEiTAQw",
   authDomain: "speed-ce2b1.firebaseapp.com",
   projectId: "speed-ce2b1",
   storageBucket: "speed-ce2b1.appspot.com",
   messagingSenderId: "787994385816",
   appId: "1:787994385816:web:90bfca485a9e05c2f49fed"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
