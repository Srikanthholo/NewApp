import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ASMT } from 'src/app/models/asmt.model';
import { ASMTService } from 'src/app/_services/asmt.service';
import { AuthService } from 'src/app/_services/auth.service';
import { StudentService } from 'src/app/_services/student.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-assignments',
  templateUrl: './assignments.component.html',
  styleUrls: ['./assignments.component.css']
})
export class AssignmentsComponent implements OnInit {

  content?: string;
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
 
  currentUser: any;
  section:any;
  studentData!: any;
  sids?: any;
  currentIndex = -1;
  customerid:any;
  totalRecords:any;
  submitted = false;


  assignment: ASMT = {
    title: '',
    description: '',
    studentid: '',
     attachedurl: '',
    customerid: '',
    published: false
  };

  constructor(private userService: UserService, 
    private studentservice:StudentService, 
    private authService: AuthService, 
    private asmtService: ASMTService,
    private tokenStorage: TokenStorageService, 
    public router: Router) { }
 
 
  ngOnInit(): void {

    this.currentUser = this.tokenStorage.getUser();
    this.getmydetails(this.currentUser.id);
     
     

  }
 

    getmydetails(id: string): void {
      
      this.studentservice.get(id)
        .subscribe({
          next: (data) => {
            this.currentUser = data;
            
          },
          error: (e) => console.error(e)
        });
    }


    getmystudents(section: string): void {
      this.section = this.currentUser.section;
      this.studentservice.findByCustmerid(section)
        .subscribe({
          next: (data) => {
          
        
            console.log(data);
            console.log(this.section);
            this.studentData = data;
            this.totalRecords=this.studentData.length;
            this.sids = data.map( (item) => item._id);
            this.customerid = this.currentUser.id;
            console.log(this.sids);
   


          },
          error: (e) => console.error(e)
        });
    }



    sendAssignment(): void{
    
      this.section = this.currentUser.section;
      this.getmystudents(this.section);
      const length = this.totalRecords;
      console.log(this.section);
      console.log(this.assignment);

      for(let j=0;j<length;j++){   
      
     
        const data = {
          title: this.assignment.title,
          description: this.assignment.description,
          attachedurl: this.assignment.attachedurl,
          
          customerid: this.currentUser._id,
          studentid: this.sids[j]
        };
    
        this.asmtService.create(data)
          .subscribe({
            next: (res) => {
              console.log(res);
              this.submitted = true;
            },
            error: (e) => console.error(e)
          });
    
     }  
    // window.location.reload();
     }
 


     newTutorial(): void {
      this.submitted = false;
      this.assignment = {
        title: '',
        description: '',
        studentid: '',
        attachedurl: '',
        customerid:'',
        published: false
      };
    }


}